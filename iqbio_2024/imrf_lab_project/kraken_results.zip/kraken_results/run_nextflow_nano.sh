#!/bin/bash
#TODO: Change conda to module for enviroment activation

# intialize conda for bash to activate env
eval "$(conda shell.bash hook)"
# set nextflow version to match pipeline v.
export NXF_VER=22.10.0
# activate pipeline enviroment
conda activate nanortax-8a6750e7c29e704fe98c2ea094c85a6b

base_dir="/home/josue/NanoRTax/fastq_pass"
# loop from barcode01 to barcode23 in order
for i in $(seq -f "%02g" 1 23); do
    reads_path="${base_dir}/barcode${i}/*.fastq.gz"
    # run nextflow command for main
    nextflow run main.nf --reads "$reads_path" -profile conda
done

# ru nextflow command for main when read is 'unclassified' file
unclassified_reads_path="${base_dir}/unclassified/*.fastq.gz"
nextflow run main.nf --reads "$unclassified_reads_path" -profile conda
